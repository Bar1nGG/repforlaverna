﻿using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.ComponentModel;

namespace laverna
{
    public partial class MainWindow : Window
    {
        private zadanielavernaEntities1 db = new zadanielavernaEntities1();
        private bool isEditing = false;
        private Equipment currentEditEquipment;

        public MainWindow()
        {
            InitializeComponent();
            LoadEquipmentFromDatabase();
            SetEditMode(false);
        }

        private void LoadEquipmentFromDatabase()
        {
            EquipmentGrid.ItemsSource = db.Equipment.ToList();
            StatusText.Text = $"Загружено записей: {db.Equipment.Count()}";
        }

        private void AddEquipment_Click(object sender, RoutedEventArgs e)
        {
            if (isEditing)
            {
                MessageBox.Show("Завершите текущее редактирование");
                return;
            }

            var newEquipment = new Equipment
            {
                Name = NameTextBox.Text,
                Type = TypeComboBox.Text,
                Status = StatusComboBox.Text
            };

            if (string.IsNullOrWhiteSpace(newEquipment.Name))
            {
                MessageBox.Show("Введите название оборудования");
                return;
            }

            db.Equipment.Add(newEquipment);
            db.SaveChanges();
            LoadEquipmentFromDatabase();
            ClearInputFields();
        }

        private void EditEquipment_Click(object sender, RoutedEventArgs e)
        {
            if (EquipmentGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите оборудование для редактирования");
                return;
            }

            if (isEditing)
            {
               
                currentEditEquipment.Name = NameTextBox.Text;
                currentEditEquipment.Type = TypeComboBox.Text;
                currentEditEquipment.Status = StatusComboBox.Text;

                db.SaveChanges();
                LoadEquipmentFromDatabase();
                SetEditMode(false);
                ClearInputFields();
            }
            else
            {
               
                currentEditEquipment = (Equipment)EquipmentGrid.SelectedItem;
                NameTextBox.Text = currentEditEquipment.Name;
                TypeComboBox.Text = currentEditEquipment.Type;
                StatusComboBox.Text = currentEditEquipment.Status;
                SetEditMode(true);
            }
        }

        private void DeleteEquipment_Click(object sender, RoutedEventArgs e)
        {
            if (EquipmentGrid.SelectedItem is Equipment selected)
            {
                if (isEditing && selected.ID == currentEditEquipment.ID)
                {
                    MessageBox.Show("Завершите редактирование перед удалением");
                    return;
                }

                if (MessageBox.Show("Удалить выбранное оборудование?", "Подтверждение",
                    MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    db.Equipment.Remove(selected);
                    db.SaveChanges();
                    LoadEquipmentFromDatabase();
                }
            }
        }

        private void SetEditMode(bool editing)
        {
            isEditing = editing;
            AddBtn.Content = editing ? "Отменить" : "Добавить";
            EditBtn.Content = editing ? "Сохранить" : "Изменить";
            DeleteBtn.IsEnabled = !editing;

            if (!editing)
            {
                currentEditEquipment = null;
            }
        }

        private void ClearInputFields()
        {
            NameTextBox.Clear();
            TypeComboBox.SelectedIndex = -1;
            StatusComboBox.SelectedIndex = -1;
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            db.Dispose();
            base.OnClosing(e);
        }
    }
}